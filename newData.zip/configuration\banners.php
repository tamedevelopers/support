<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Template File Lines
    |--------------------------------------------------------------------------
    |
    | The following template lines are used during text formatting for various
    | messages that we need to display to the user. You are free to modify
    | these template lines according to your application's requirements.
    |
    */

    0 =>
    array (
    'id' => '1',
    'image' => '1641091145e5b7a7e1d49ea7c.jpg',
    'active' => '1',
    'created_at' => NULL,
    'updated_at' => NULL,
    ),
    1 =>
    array (
    'id' => '2',
    'image' => '1664740030ecbe7957d14eaa7.jpg',
    'active' => '1',
    'created_at' => NULL,
    'updated_at' => NULL,
    ),
    2 =>
    array (
    'id' => '3',
    'image' => '165353683347c9eea1a5bd77e.jpg',
    'active' => '1',
    'created_at' => NULL,
    'updated_at' => NULL,
    ),
];